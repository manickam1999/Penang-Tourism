var a = [['Kids on bicycle',5.414674, 100.338270,"info1"],
		['Boy on Chair',5.414921, 100.336637, "info2"],
		['Old Man',5.41539, 100.3372, "info3"],
		['Kung Fu Girl', 5.419800, 100.335858, "info4"],
		['Trishaw Man', 5.421385, 100.333731,"info5"],
		['Old Motorcycle', 5.41535, 100.33889,"info6"],
		['Children in a boat' , 5.41205, 100.3405,"info7"]];
		
var citymap	= {center: {lat:5.417516, lng: 100.337507}}
var markerArray = [];
var i;
var dirService = new google.maps.DirectionsService;
var dirDisplay = new google.maps.DirectionsRenderer;
var map;
var mapOptions;




function openInfo(infowindow,coords)
{
	document.getElementById(infowindow).style.width = "400px";
	document.getElementById(infowindow).style.transition = "0.5s";
	document.getElementById("main").style.width = "0";
	map.setCenter(coords);
	map.setZoom(19);
}

function openNav()
{
		document.getElementById("main").style.width = "400px";
		document.getElementById("main").style.transition = "0.5s";
		document.getElementById("info1").style.width = "0";
		document.getElementById("info1").style.width = "0";
		document.getElementById("info6").style.width = "0";
		document.getElementById("info2").style.width = "0";
		document.getElementById("info3").style.width = "0";
		document.getElementById("info4").style.width = "0";
		document.getElementById("info5").style.width = "0";
		document.getElementById("info7").style.width = "0";
	
}

function routeMake(dirService, dirDisplay) 
{
    dirService.route({origin: document.getElementById('start').value, destination: document.getElementById('end').value, travelMode: document.getElementById('transport').value}, 
	function(response, status) 
	{
        if (status == 'OK') 
		{
           dirDisplay.setDirections(response);
        } 
		else 
		{
           window.alert('Directions request failed due to ' + status);
        }
	});	
}

function loadMap()
{
	
	var routeMker = function() { routeMake(dirService,dirDisplay ); map.setZoom(19); };
	mapOptions = 
	{
		center: new google.maps.LatLng(5.415998, 100.337298),
		zoom : 16,
		mapTypeId : google.maps.MapTypeId.ROADMAP
	};
	
	map = new google.maps.Map(document.getElementById("interactivemap"), mapOptions);
	
	
	var shapeIcon = 
	{
          coords: [0,16,16,0,24,0,36,16,36,24,18,58],
          type: 'poly'
    };
	
	var shapeCircle =
	{
		coords : [],
		type : 'poly'
	};
	
	dirDisplay.setMap(map)
	
	var iconBase = 
	{
		url : 'https://image.ibb.co/j9Vva6/final4.png',
		anchor: new google.maps.Point(30.5, 48.5)
	};
	
	for(i = 0; i < a.length ; i++) /* Marker Creator */
	{	
		var marker = new google.maps.Marker
		({
		position : new google.maps.LatLng(a[i][1],a[i][2]),
		icon : iconBase,
		shape : shapeIcon,
		map : map,
		animation : google.maps.Animation.DROP
		});
		//marker.setVisible(false)
		markerArray.push(marker);
		
		
	}
	
	google.maps.event.addDomListener(document.getElementById("button"),"click",function()
	{
		if(markerArray[0].visible)
		{
			for(i=0 ; i < markerArray.length ; i++)
			{
				markerArray[i].setVisible(false);
			}
		}
		else
		{
			for(i=0 ; i < markerArray.length ; i++)
			{
				markerArray[i].setVisible(true);
			}
		}
	});
	
	
	google.maps.event.addDomListener(map,"click", function()
	{
		if(map.getZoom() > 16)
		{
			map.setZoom(16);
			map.setCenter({lat : 5.415998 , lng : 100.337298});
			document.getElementById("info1").style.width = "0";
			document.getElementById("info1").style.width = "0";
			document.getElementById("info6").style.width = "0";
			document.getElementById("info2").style.width = "0";
			document.getElementById("info3").style.width = "0";
			document.getElementById("info4").style.width = "0";
			document.getElementById("info5").style.width = "0";
			document.getElementById("info7").style.width = "0";
		}
	});
	
	
	markerArray.forEach(function(marker)
	{
		marker.addListener("mouseover", function()
		{
			if (marker.getAnimation() != null) 
			{
				marker.setAnimation(null);
			} 
			else 
			{
				marker.setAnimation(google.maps.Animation.BOUNCE);
			}
		});
		marker.addListener("mouseout", function()
		{
			if (marker.getAnimation() != null) 
			{
				marker.setAnimation(null);
			} 
			else 
			{
				marker.setAnimation(google.maps.Animation.BOUNCE);
			}
		});
		marker.addListener("click", function()
		{
				map.setZoom(19);
				map.setCenter(marker.getPosition());
		});
	});
	
	google.maps.event.addDomListener(markerArray[0], "click" ,function()
	{
			document.getElementById("info1").style.width = "400px";
			document.getElementById("info1").style.transition = "0.5s";
			document.getElementById("main").style.width = "0";
			document.getElementById("info6").style.width = "0";
			document.getElementById("info2").style.width = "0";
			document.getElementById("info3").style.width = "0";
			document.getElementById("info4").style.width = "0";
			document.getElementById("info5").style.width = "0";
			document.getElementById("info7").style.width = "0";
	});
	
	google.maps.event.addDomListener(markerArray[1], "click" ,function()
	{
			document.getElementById("info2").style.width = "400px";
			document.getElementById("info2").style.transition = "0.5s";
			document.getElementById("main").style.width = "0";
			document.getElementById("info1").style.width = "0";
			document.getElementById("info6").style.width = "0";
			document.getElementById("info3").style.width = "0";
			document.getElementById("info4").style.width = "0";
			document.getElementById("info5").style.width = "0";
			document.getElementById("info7").style.width = "0";
	});
	
	google.maps.event.addDomListener(markerArray[2], "click" ,function()
	{
			document.getElementById("info3").style.width = "400px";
			document.getElementById("info3").style.transition = "0.5s";
			document.getElementById("main").style.width = "0";
			document.getElementById("info1").style.width = "0";
			document.getElementById("info2").style.width = "0";
			document.getElementById("info6").style.width = "0";
			document.getElementById("info4").style.width = "0";
			document.getElementById("info5").style.width = "0";
	});
	
	google.maps.event.addDomListener(markerArray[3], "click" ,function()
	{
			document.getElementById("info4").style.width = "400px";
			document.getElementById("info4").style.transition = "0.5s";
			document.getElementById("main").style.width = "0";
			document.getElementById("info1").style.width = "0";
			document.getElementById("info2").style.width = "0";
			document.getElementById("info3").style.width = "0";
			document.getElementById("info6").style.width = "0";
			document.getElementById("info5").style.width = "0";
			document.getElementById("info7").style.width = "0";
	});
	
	google.maps.event.addDomListener(markerArray[4], "click" ,function()
	{
			document.getElementById("info5").style.width = "400px";
			document.getElementById("info5").style.transition = "0.5s";
			document.getElementById("main").style.width = "0";
			document.getElementById("info1").style.width = "0";
			document.getElementById("info2").style.width = "0";
			document.getElementById("info3").style.width = "0";
			document.getElementById("info4").style.width = "0";
			document.getElementById("info6").style.width = "0";
			document.getElementById("info7").style.width = "0";
	});
	
	google.maps.event.addDomListener(markerArray[5], "click" ,function()
	{
			document.getElementById("info6").style.width = "400px";
			document.getElementById("info6").style.transition = "0.5s";
			document.getElementById("main").style.width = "0";
			document.getElementById("info1").style.width = "0";
			document.getElementById("info2").style.width = "0";
			document.getElementById("info3").style.width = "0";
			document.getElementById("info4").style.width = "0";
			document.getElementById("info5").style.width = "0";
			document.getElementById("info7").style.width = "0";
	});
	
	google.maps.event.addDomListener(markerArray[6], "click" ,function()
	{
			document.getElementById("info7").style.width = "400px";
			document.getElementById("info7").style.transition = "0.5s";
			document.getElementById("main").style.width = "0";
			document.getElementById("info1").style.width = "0";
			document.getElementById("info2").style.width = "0";
			document.getElementById("info3").style.width = "0";
			document.getElementById("info4").style.width = "0";
			document.getElementById("info5").style.width = "0";
			document.getElementById("info6").style.width = "0";
	});
	

		
	
	var cityCircle = new google.maps.Circle
	({
			strokeColor: '#00bfff',
			strokeOpacity: 0.8,
			strokeWeight: 2,
			fillColor: '#b0e0e6',
			fillOpacity: 0.25,
			map: map,
			center: citymap.center,
			radius: 750,
			shape : shapeCircle
	});
	cityCircle.setVisible(false);
	google.maps.event.addDomListener(document.getElementById("button1"), "click" , function()
	{
		if(cityCircle.visible)
		{
			cityCircle.setVisible(false)
		}
		
		else
		{
			cityCircle.setVisible(true)
		}
	});
	
	google.maps.event.addDomListener(document.getElementById("button2"),"click",routeMker); 
	google.maps.event.addDomListener(document.getElementById("button3"),"click",function()
	{
		if(document.getElementById("main").style.width == "400px")
		{
			document.getElementById("main").style.width = "0";
		}
		else
		{
			document.getElementById("main").style.width = "400px";
			document.getElementById("main").style.transition = "0.5s";
			document.getElementById("info1").style.width = "0";
			document.getElementById("info1").style.width = "0";
			document.getElementById("info6").style.width = "0";
			document.getElementById("info2").style.width = "0";
			document.getElementById("info3").style.width = "0";
			document.getElementById("info4").style.width = "0";
			document.getElementById("info5").style.width = "0";
			document.getElementById("info7").style.width = "0";
		}
	});
	 
	
			
}
google.maps.event.addDomListener(window,"load",loadMap);



